#!/bin/bash
set -e

# RCO Ψ-V5.1.0 "Sovereign Inversion" Setup
# Hardware-Bound Deployment & Integrity Audit

echo "--- [RCO Ψ-V5.1.0] Sovereign Environment Setup ---"

# 1. Hardware Sovereignty Audit (TPM 2.0)
echo "[1/4] Auditing Hardware Sovereignty..."
if [ ! -c "/dev/tpmrm0" ]; then
    echo "WARNING: /dev/tpmrm0 (TPM 2.0 Resource Manager) not found."
    echo "RCO-v5-Psi requires hardware-bound identity. Manifold will run in 'Simulated Mode'."
else
    echo "TPM 2.0 Hardware: DETECTED"
fi

# 2. Runtime Integrity Audit (Julia & Python)
echo "[2/4] Verifying Polyglot Runtimes..."
if ! command -v julia &> /dev/null; then
    echo "Error: Julia is required for modeling. (https://julialang.org/)"
    exit 1
fi
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is required for high-level scripting."
    exit 1
fi
echo "Julia $(julia --version | awk '{print $3}') : OK"
echo "Python $(python3 --version | awk '{print $2}') : OK"

# 3. Binary & Distribution Audit
echo "[3/4] Validating Sovereign Core..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_DIR="${SCRIPT_DIR}/../dist"
LIB_PATH="${DIST_DIR}/lib/librco_core.so"

if [ ! -f "$LIB_PATH" ]; then
    echo "Error: librco_core.so not found in dist/lib."
    echo "Please ensure the Ψ-V5.1.0 distribution package is intact."
    exit 1
fi

# Architecture detection for Assembly Kernels
ARCH=$(uname -m)
echo "Platform: $ARCH"
echo "Core Path: $LIB_PATH"

# 4. Forensic Manifest Verification
echo "[4/4] Verifying Forensic Manifest..."
MANIFEST="${DIST_DIR}/manifest.json"
if [ -f "$MANIFEST" ]; then
    EXPECTED_HASH=$(grep -oP '"hash": "\K[^"]+' "$MANIFEST")
    ACTUAL_HASH=$(sha256sum "$LIB_PATH" | awk '{print $1}')
    
    if [ "$EXPECTED_HASH" == "$ACTUAL_HASH" ]; then
        echo "Integrity: BIT-PERFECT (Forensic Match)"
    else
        echo "CAUTION: Hash mismatch detected. Binary integrity compromised!"
    fi
else
    echo "Note: No manifest found. Manual integrity check recommended."
fi

echo "--- [RCO Ψ-V5.1.0] Setup Complete. Sovereign Inversion Initialized. ---"
